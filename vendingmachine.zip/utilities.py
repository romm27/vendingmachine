import os

def clear_console():
    os.system('cls')
    return
